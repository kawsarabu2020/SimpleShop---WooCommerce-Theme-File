<!--hero section start-->
<section class="page-title">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <nav class="woocommerce-breadcrumb">
                   <!-- <a href="#">Home</a>
                    <span class="breadcrumb-separator"> / </span>
                    <a href="#">Accessories</a>
                    <span class="breadcrumb-separator"> / </span>Beanie  -->
                    <?php woocommerce_breadcrumb(); ?>
                </nav>
            </div>
        </div>
    </div>
</section>